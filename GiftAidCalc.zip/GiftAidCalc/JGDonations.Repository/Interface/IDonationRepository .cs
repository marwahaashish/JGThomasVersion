﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JGDonations.Model;
using Models = JGDonations.Model.Abstract;


namespace JGDonations.Repository
{
    public interface IDonationRepository
    {
         int Get(int Id);
         void Add(Models.IDonation addentity);
         void Update(Models.IDonation updateentity);
         void Delete(Models.IDonation deleteentity); 
         double CalculateGiftAidAmount(double amount, double taxRate);
         double CalculateSupplementAmount(double donationAmount, double supplimentPercentage);
    }
}
