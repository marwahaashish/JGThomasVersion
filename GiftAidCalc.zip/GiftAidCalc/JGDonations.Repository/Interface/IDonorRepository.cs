﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Models = JGDonations.Model.Abstract;


namespace JGDonations.Repository
{
    public interface IDonorRepository
    {
         int Get(int Id);
         void Add(Models.IDonor addentity);
         void Update(Models.IDonor updateentity);
         void Delete(Models.IDonor deleteentity); //?? wht entity ??
    }
}
