﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JGDonations;
using JGDonations.Model;
using Models = JGDonations.Model.Abstract;

namespace JGDonations.Repository
{
    public interface IGiftAidRateRepository
    {
             int Get(int Id);
             void Add(Models.IGiftAidRate addentity);
             void Update(Models.IGiftAidRate updateentity);
             void Delete(Models.IGiftAidRate deleteentity);
    
    }
}
    