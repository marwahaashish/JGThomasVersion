﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JGDonations.Model;
using Models = JGDonations.Model.Abstract;

namespace JGDonations.Repository
{
  public interface IEventRepository
    {
         int Get(int Id);
         void Add(Models.IEvent addentity);
         void Update(Models.IEvent updateentity);
         void Delete(Models.IEvent deleteentity);
    }
}
