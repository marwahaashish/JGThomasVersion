﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JGDonations.Repository;
using Models = JGDonations.Model.Abstract;

namespace JGDonations.Data
{
    class EventData : IEventRepository
    {


        int IEventRepository.Get(int Id)
        {
            throw new NotImplementedException();
        }

        void IEventRepository.Add(Models.IEvent addentity)
        {
            throw new NotImplementedException();
        }

        void IEventRepository.Update(Models.IEvent updateentity)
        {
            throw new NotImplementedException();
        }

        void IEventRepository.Delete(Models.IEvent deleteentity)
        {
            throw new NotImplementedException();
        }
    }
}
