﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JGDonations.Repository;
using Models = JGDonations.Model.Abstract;

namespace JGDonations.Data
{
    class DonorData : IDonorRepository
    {
        int IDonorRepository.Get(int Id)
        {
            throw new NotImplementedException();
        }

        void IDonorRepository.Add(Models.IDonor addentity)
        {
            throw new NotImplementedException();
        }

        void IDonorRepository.Update(Models.IDonor updateentity)
        {
            throw new NotImplementedException();
        }

        void IDonorRepository.Delete(Models.IDonor deleteentity)
        {
            throw new NotImplementedException();
        }
    }
}
