﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JGDonations.Repository;
using Models = JGDonations.Model.Abstract;

namespace JGDonations.Data
{
    public class GiftAidRateData : IGiftAidRateRepository
    {



        int IGiftAidRateRepository.Get(int Id)
        {
            throw new NotImplementedException();
        }

        void IGiftAidRateRepository.Add(Models.IGiftAidRate addentity)
        {
            throw new NotImplementedException();
        }

        void IGiftAidRateRepository.Update(Models.IGiftAidRate updateentity)
        {
            throw new NotImplementedException();
        }

        void IGiftAidRateRepository.Delete(Models.IGiftAidRate deleteentity)
        {
            throw new NotImplementedException();
        }
    }
}
