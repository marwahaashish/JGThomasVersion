﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JGDonations.Repository;
using Models = JGDonations.Model.Abstract;

namespace JGDonations.Data
{
    class DonationData : IDonationRepository
    {


        double IDonationRepository.CalculateGiftAidAmount(double amount, double taxRate)
        {
            var giftAidRatio = taxRate / (100 - taxRate);
            return amount * giftAidRatio;
        }

        double IDonationRepository.CalculateSupplementAmount(double donationAmount, double supplimentPercentage)
        {
            throw new NotImplementedException();
        }

        int IDonationRepository.Get(int Id)
        {
            throw new NotImplementedException();
        }

        void IDonationRepository.Add(Models.IDonation addentity)
        {
            throw new NotImplementedException();
        }

        void IDonationRepository.Update(Models.IDonation updateentity)
        {
            throw new NotImplementedException();
        }

        void IDonationRepository.Delete(Models.IDonation deleteentity)
        {
            throw new NotImplementedException();
        }
    }
}
