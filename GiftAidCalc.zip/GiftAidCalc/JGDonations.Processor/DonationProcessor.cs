﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JGDonations.Common;
using JGDonations.Model;
using JGDonations.Repository;

namespace JGDonations.Processor
{
    class DonationProcessor
    {
         private IDonationRepository _donationRepository;
         public DonationProcessor(IDonationRepository donationRepository)
        {
            _donationRepository = donationRepository;
        }
    }
}
