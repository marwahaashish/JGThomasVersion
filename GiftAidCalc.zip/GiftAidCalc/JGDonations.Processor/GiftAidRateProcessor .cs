﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JGDonations.Common;
using JGDonations.Model;
using JGDonations.Repository;


namespace JGDonations.Processor
{
    public class GiftAidRateProcessor
    {
        private IGiftAidRateRepository _gifAidRepository;
        public GiftAidRateProcessor(IGiftAidRateRepository gifAidRepository)
        {
            _gifAidRepository = gifAidRepository;
        }
    }
}
