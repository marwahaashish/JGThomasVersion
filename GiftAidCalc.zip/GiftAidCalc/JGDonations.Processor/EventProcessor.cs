﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JGDonations.Common;
using JGDonations.Model;
using JGDonations.Repository;

namespace JGDonations.Processor
{
    class EventProcessor
    {
        private IEventRepository _eventRepository;
        public EventProcessor(IEventRepository eventRepository)
        {
            _eventRepository = eventRepository;
        }
    }
}
