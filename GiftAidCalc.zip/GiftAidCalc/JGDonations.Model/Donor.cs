﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JGDonations.Model.Abstract;

namespace JGDonations.Model
{
    public class Donor : IDonor
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string EmailAddress { get; set; }        
    }
}
