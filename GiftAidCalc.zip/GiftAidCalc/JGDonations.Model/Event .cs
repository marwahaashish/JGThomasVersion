﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JGDonations.Model.Abstract;

namespace JGDonations.Model
{
    public class Event : IEvent
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Type { get; set; }
        public double Supplement { get; set; }        
    }
}
