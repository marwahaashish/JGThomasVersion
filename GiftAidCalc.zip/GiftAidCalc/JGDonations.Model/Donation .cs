﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JGDonations.Model.Abstract;

namespace JGDonations.Model
{
   public class Donation : IDonation
    {
        public int Id { get; set; }
        public int Event { get; set; }
        public string Donor { get; set; }
        public double Amount { get; set; }
        public double GiftAidRate { get; set; }
    }
}
