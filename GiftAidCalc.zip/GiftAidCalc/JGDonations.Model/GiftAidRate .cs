﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JGDonations.Model.Abstract;

namespace JGDonations.Model
{
    public class GiftAidRate : IGiftAidRate
    {
        public int Id { get; set; }
        public double Rate { get; set; }
        
    }
}
