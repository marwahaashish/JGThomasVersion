﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JGDonations.Model.Abstract
{
    public class IEvent 
    {
         int Id { get; set; }
         string Name { get; set; }
         int Type { get; set; }
         double Supplement { get; set; }        
    }
}
