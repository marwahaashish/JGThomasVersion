﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JGDonations.Model.Abstract
{
    public class IDonor
    {
         int Id { get; set; }
         string Name { get; set; }
         string EmailAddress { get; set; }        
    }
}
