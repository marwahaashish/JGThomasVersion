﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JGDonations.Model.Abstract
{
   public interface IDonation
    {
         int Id { get; set; }
         int Event { get; set; }
         string Donor { get; set; }
         double Amount { get; set; }
         double GiftAidRate { get; set; }
    }
}
