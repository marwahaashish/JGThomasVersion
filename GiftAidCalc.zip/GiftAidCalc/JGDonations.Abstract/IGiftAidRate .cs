﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JGDonations.Model.Abstract
{
    public class IGiftAidRate
    {
         int Id { get; set; }
         double Rate { get; set; }
        
    }
}
